package com.refirx.application.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.refirx.application.constant.UrlConstant;
import com.refirx.application.dto.user.LoginForm;
import com.refirx.application.enums.ErrorCode;
import com.refirx.application.enums.ResponseCode;
import com.refirx.application.model.City;
import com.refirx.application.model.State;
import com.refirx.application.model.UserCredentials;
import com.refirx.application.service.common.LocalService;
import com.refirx.application.service.user.CountryModelService;
import com.refirx.application.service.user.StateListService;
import com.refirx.application.service.user.UserCredentialsService;
import com.refirx.application.utils.ErrorCollectionUtil;
import com.refirx.application.utils.ResponseHandler;

import io.swagger.annotations.Api;



@Api
@RestController
public class StateListController {
	
	@Autowired
	StateListService stateListService;
	@Autowired
	CountryModelService countryservice;
	
	@Autowired
	private LocalService localService;

	@Autowired
	private UserCredentialsService userCredentialsService;

	private static final Logger LOGGER = LoggerFactory.getLogger(StateListController.class);
	
//Fetching state List
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = UrlConstant.state_name)
	public ResponseEntity<Object> getStateList(@RequestParam(defaultValue = "USA") String countryName,
			HttpServletRequest request) {
		List<State> list = countryservice.findByCountryName(countryName);

		List<String> namelist = new ArrayList<String>();
		for (State name : list) {
			String stateName = name.getStateName().toString();
			namelist.add(stateName);
		}
		
		return ResponseHandler.response(HttpStatus.OK, false, localService.getMessage("Data.Found"), ErrorCode.OK,
				ResponseCode.ACKNOWLEDGE, namelist);
	}
	
	/*
	 * @CrossOrigin(origins = "*", allowedHeaders = "*")
	 * 
	 * @PostMapping(value = UrlConstant.state_name) public List<String>
	 * getStateList( @PathVariable(name = "country_code") String countryId) {
	 * //List<State> list = stateListService.findByCountry_Code(countryCode);
	 * 
	 * List<State> list = countryservice.findByCountryCode(countryId);
	 * 
	 * List<String> namelist = new ArrayList<String>(); for (State name : list) {
	 * String stateName = name.getStateName().toString(); namelist.add(stateName); }
	 * 
	 * return namelist;
	 * 
	 */	
	
	//Fetching city List
	
	//private static final Logger LOGGER = LoggerFactory.getLogger(StateListController.class);
	/*
	 * @CrossOrigin(origins = "*", allowedHeaders = "*")
	 * 
	 * @PostMapping(value = UrlConstant.city_name) public List<String>
	 * getCityList( @PathVariable(name = "state_id") String stateId) { //List<State>
	 * list = stateListService.findByCountry_Code(countryCode);
	 * 
	 * List<City> citylist = stateListService.findByStateId(stateId);
	 * 
	 * 
	 * List<String> namelist = new ArrayList<String>(); for (City name : citylist) {
	 * String stateName = name.getName().toString(); System.out.println("state name"
	 * + stateName); namelist.add(stateName); }
	 * 
	 * return namelist;
	 * 
	 * }
	 */
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = UrlConstant.city_name)
	public ResponseEntity<Object> getCityList(@RequestParam(defaultValue = "1") String stateId,
			HttpServletRequest request) {

		List<City> citylist = stateListService.findByStateId(stateId);

		List<String> namelist = new ArrayList<String>();
		for (City name : citylist) {
			String stateName = name.getName().toString();
			System.out.println("state name" + stateName);
			namelist.add(stateName);
		}
		return ResponseHandler.response(HttpStatus.OK, false, localService.getMessage("Data.Found"), ErrorCode.OK,
				ResponseCode.ACKNOWLEDGE, namelist);
	}
}
