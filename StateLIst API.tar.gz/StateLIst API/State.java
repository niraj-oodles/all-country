package com.refirx.application.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "state")
public class State {

	
	@Id
	@GeneratedValue
	@Column(name = "state_id")
	private String stateCode;

	@Column(name = "state_name")
	private String stateName;

	@ManyToOne
	@JoinColumn(name = "country_id")
	private CountryModel countryModel;

	@Column(name = "status")
	String status;

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public CountryModel getCountryModel() {
		return countryModel;
	}

	public void setCountryModel(CountryModel countryModel) {
		this.countryModel = countryModel;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "State [stateCode=" + stateCode + ", stateName=" + stateName + ", countryModel=" + countryModel
				+ ", status=" + status + "]";
	}
	 
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue
	 * 
	 * @Column(name = "state_id") private String stateCode;
	 * 
	 * @Column(name = "state_name") private String stateName;
	 * 
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "country_id") private Country country;
	 * 
	 * @Column(name = "status") String status;
	 * 
	 * public String getStateCode() { return stateCode; }
	 * 
	 * public void setStateCode(String stateCode) { this.stateCode = stateCode; }
	 * 
	 * public String getStateName() { return stateName; }
	 * 
	 * public void setStateName(String stateName) { this.stateName = stateName; }
	 * 
	 * 
	 * public Country getCountry() { return country; }
	 * 
	 * public void setCountry(Country country) { this.country = country; }
	 * 
	 * public String getStatus() { return status; }
	 * 
	 * public void setStatus(String status) { this.status = status; }
	 * 
	 * @Override public String toString() { return "State [stateCode=" + stateCode +
	 * ", stateName=" + stateName + ", country=" + country + ", status=" + status +
	 * "]"; }
	 */
}
