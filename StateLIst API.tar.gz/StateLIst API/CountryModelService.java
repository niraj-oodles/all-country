package com.refirx.application.service.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.refirx.application.model.CountryModel;
import com.refirx.application.model.State;
import com.refirx.application.repo.StateRepo;
import com.refirx.application.repo.common.CountryModelRepo;

@Service
public class CountryModelService {

	@Autowired
	private CountryModelRepo countryModelRepo;
	@Autowired
	private StateRepo stateRepo;

	public List<State> findByCountryName(String countryName) {
		String countryId=null;
		//CountryModel countryModel = countryModelRepo.findByCountryModelcountryName(countryName);
		List<CountryModel> allList = countryModelRepo.findAll();
		for(CountryModel country:allList)
		{
			if((country.getCountryName()).equals(countryName))
			{
				countryId = country.getCountryId();	
			}
		}
		
		return stateRepo.findByCountryModelCountryId(countryId);
	
}
	
}


