package com.refirx.application.constant;

public class UrlConstant {

	/**
	 * default constructor because utility classes, which are collections of static
	 * members, are not meant to be instantiated. Even abstract utility classes,
	 * which can be extended, should not have public constructors.
	 */
	private UrlConstant() {
	}
	

	public static final String BASEURL = "api/v1";
	public static final String LOGIN = BASEURL + "/login";
	public static final String REGISTER = BASEURL + "/register";
	public static final String AGENTREGISTER = BASEURL + "/agent/register";
	public static final String REGISTER_MAIL_VERIFY = BASEURL + "/verify";
	public static final String AGENTLOGIN = BASEURL + "/agent/login";

	public static final String LOGOUT = BASEURL + "/logout";
	public static final String FORGOT_PASS = BASEURL + "/forgotpassword";
	public static final String FORGET_PASS_VERIFY = BASEURL + "/resetpassword/mail/verify";
	public static final String GET_USER_PROFILE = BASEURL + "/user/profile";
	public static final String UPDATE_USER_PROFILE = BASEURL + "/update/profile";
	
	/**
	 * StateList API
	 */
	public static final String state_name = BASEURL + "/countryName";
	
	/**
	 * CityList API
	 */
	public static final String city_name = BASEURL + "/city";
	/**
	 * CONSUMER API
	 */
	public static final String CONSUMER = BASEURL + "/consumer";

	public static final String UPDATE_CONSUMER = BASEURL + "/updateconsumer";

	public static final String DELETE_CONSUMER = BASEURL + "/deleteconsumer";

	public static final String DELETE_CONSUMER_ID = DELETE_CONSUMER + "/{id}";

	public static final String GET_CONSUMER = BASEURL + "/getconsumer";

	public static final String GET_CONSUMER_ID = GET_CONSUMER + "/{id}";

	/**
	 * AGENT API
	 */

	public static final String AGENT = BASEURL + "/agent";

	public static final String AgentId = "/{agentId}";

	/**
	 * CONSUMER API
	 */
	public static final String LOANREQUEST = BASEURL + "/loan/request";

	public static final String LOAN_ID = "/{loanId}";

	/*
	 * BID API
	 */
	public static final String BID = BASEURL + "/bid";

	public static final String BID_ID = "/{id}";

	public static final String ACTIVEBID = "/active";
	public static final String LOSTBID = "/lost";

	public static final String CURRENTLOAN = "/currentLoan";
	
	public static final String state = BASEURL + "/state";
	
	public static final String statename = BASEURL + "/{state}";

	/**
	 * USER API
	 */
	public static final String LOCAL_DOMAIN = "http://localhost:8080";

	public static final String CHANGE_SUB_ADMIN_PASS_BY_SUPER_ADMIN = BASEURL
			+ "/change/sub-admin/password/by/super-admin";

	public static final String ADD_MOBILE_NUMBER = BASEURL + "/mobile/number";

	public static final String RESET_PASS_SUBMIT = BASEURL + "/reset/password";

	public static final String ROLE_URI = BASEURL + "/role";

	public static final String PRIVILEGE_URI = BASEURL + "/privilege";

	public static final String REGISTER_SUB_ADMIN = BASEURL + "/register/admin";

	public static final String CHANGE_PASS = BASEURL + "/change/password";

	public static final String BLOCK_ACCOUNT_REQUEST_BY_USER = BASEURL + "/block/user/forgery";

	public static final String RESET_PASS_AGAINST_FORGERY_LOGIN = BASEURL + "/reset/credentials/forgery/login";

	/**
	 * Document Controller
	 */
	public static final String DOCUMENT = BASEURL + "/document";

	// ADMIN SIDE CONSTANTS
	public static final String ADMIN_VERIFICATION_LINK_SET_PASS = BASEURL + "/set/password";

	public static final String ADMIN_FORGOT_PASS = BASEURL + "/admin/forgot/password";

	public static final String ADMIN_RESET_PASS_SUBMIT = BASEURL + "/admin/reset/password";

	public static final String SUPER_ADMIN_LOGIN = BASEURL + "/admin/login";

	public static final String ADMIN_LOGOUT = BASEURL + "/admin/logout";

	public static final String SUB_ADMIN_EMAIL_VERIFY = BASEURL + "/admin/verify/mail";

	public static final String SET_PASS_BY_SUB_ADMIN = BASEURL + "/admin/set/password";

	public static final String SET_SUPER_ADMIN_PASS = BASEURL + "/admin/first/password";

	public static final String ADD_PRIVILEGE = BASEURL + "/add/privilege";

	public static final String PRIVILEGE_ASSIGN_TO_ROLE = BASEURL + "/assign/privilege/role";

	public static final String ROLE_LIST = BASEURL + "/list/roles";

	public static final String ROLE_EDIT_NAME_DESCRIPTION = BASEURL + "/edit/role/description/name";

	public static final String ENABLE_DISABLE_ROLE = BASEURL + "/enable/disable/role";

	public static final String DISABLE_PRIVILEGE_FOR_ROLE = BASEURL + "/remove/privilege/role";

	public static final String SUPER_ADMIN_ID = BASEURL + "/admin/id";

	public static final String CONTINUE_WITH_CURRENT_SESSION = BASEURL + "/current/session/continue";

	public static final String ADMIN_ADD_MOBILE_NUMBER = BASEURL + "/admin/add/mobile/number";

	public static final String CHANGE_SUB_ADMIN_PASS = BASEURL + "/change/sub-admin/password";

	// Privilege Controller
	public static final String LOGGED_IN_PRIVILEGES = BASEURL + "/logged/in/user/privileges";
	public static final String TOKEN_SECRET = BASEURL + "/token/secret";

	public static final String UPLOADIMAGE = BASEURL + "/uploadimage";
	public static final String GETIMAGE = BASEURL + "/getimage";

}
