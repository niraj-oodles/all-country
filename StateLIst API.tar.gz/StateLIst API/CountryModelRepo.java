package com.refirx.application.repo.common;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.refirx.application.model.CountryModel;
import com.refirx.application.model.State;

@Repository
public interface CountryModelRepo extends JpaRepository<CountryModel, String> {

	CountryModel findByCountryName(String countryName);

	
}
