/**
 * 
 */
package com.refirx.application.repo.common;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.refirx.application.model.City;
import com.refirx.application.model.State;

/**
 * @author rahulsharma
 *
 */

@Repository
public interface StateRepo extends JpaRepository<State, String>{
	
	List<State> findByCountryModelCountryId(String countryId);

	

	
}
