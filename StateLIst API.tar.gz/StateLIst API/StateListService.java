package com.refirx.application.service.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.refirx.application.model.City;
import com.refirx.application.repo.common.CityRepo;

@Service
public class StateListService {

	
	@Autowired
	private CityRepo cityRepo;

	public List<City> findByStateId(String stateId) {
		List<City> cityList = cityRepo.findByStateStateCode(stateId);// TODO Auto-generated method stub
		return cityList;
	}



}
