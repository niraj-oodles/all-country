package com.refirx.application.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "country_list")
public class CountryModel {

	@Id
	@GeneratedValue
	@Column(name = "country_id")
	private String countryId;

	@Column(name = "country_name")
	private String countryName;

	@Column(name = "status")
	private String status;

	@Column(name = "country_code")
	private String countryCode;

	@OneToMany(mappedBy = "countryModel", cascade = CascadeType.ALL)
	List<State> state = new ArrayList<State>();

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public List<State> getState() {
		return state;
	}

	public void setState(List<State> state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "CountryModel [countryId=" + countryId + ", countryName=" + countryName + ", status=" + status
				+ ", countryCode=" + countryCode + ", state=" + state + "]";
	}

}