package com.refirx.application.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

import com.refirx.application.constant.UrlConstant;
import com.refirx.application.security.filter.JWTAuthenticationFilter;
import com.refirx.application.security.filter.JWTAuthorizationFilter;

/**
 * 
 * @author shivani
 *
 */
@EnableWebSecurity
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfiguration.class);

	@Override
	public void init(WebSecurity web) throws Exception {
		super.init(web);

	}

	/**
	 * 
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		LOGGER.debug("**********************SECURITY INITALIZE NORMAL#######################################");

		http.cors().and().csrf().disable().authorizeRequests().anyRequest().authenticated().and()
				.addFilter(new JWTAuthenticationFilter(authenticationManager(), getApplicationContext()))
				.addFilter(new JWTAuthorizationFilter(authenticationManager()))

				// this disables session creation on Spring Security
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

	}

	/**
	 *
	 */
	@Override
	public void configure(WebSecurity web) throws Exception {
		
		web.ignoring().antMatchers("/google");
		web.ignoring().antMatchers("/v2/api-docs/**");
		web.ignoring().antMatchers("/swagger.json");
		web.ignoring().antMatchers("/swagger-ui.html");
		web.ignoring().antMatchers("/webjars/**");
		web.ignoring().antMatchers("/swagger-resources/**");

		web.ignoring().antMatchers("/api/v1/agent/login");

		web.ignoring().antMatchers("/api/v1/register");
		web.ignoring().antMatchers("/api/v1/verify");
		web.ignoring().antMatchers("/api/v1/forgotpassword");
		web.ignoring().antMatchers("/api/v1/resetpassword/mail/verify");
		web.ignoring().antMatchers("/api/v1/login");
		web.ignoring().antMatchers("/api/v1/admin/login");
		web.ignoring().antMatchers("/api/v1/reset/password");
		web.ignoring().antMatchers("/api/v1/mobile/number");

		// Admin URL configurations
		web.ignoring().antMatchers("/api/v1/admin/set/password");
		web.ignoring().antMatchers(HttpMethod.GET, "/" + UrlConstant.SUB_ADMIN_EMAIL_VERIFY);
		web.ignoring().antMatchers(HttpMethod.PUT, "/" + UrlConstant.ADMIN_ADD_MOBILE_NUMBER);

		web.ignoring().antMatchers("/api/v1/verify/google/auth/key");
		web.ignoring().antMatchers("/api/v1/2FA/via/mobile");
		web.ignoring().antMatchers("/api/v1/admin/id");
		web.ignoring().antMatchers("/api/v1/admin/info");
		web.ignoring().antMatchers("/api/v1/countryName");
		web.ignoring().antMatchers("/api/v1/city");
		web.ignoring().antMatchers("/" + UrlConstant.SET_SUPER_ADMIN_PASS);

		/**
		 * consumer API
		 */

		// web.ignoring().antMatchers("/" + UrlConstant.UPDATE_CONSUMER);
		// web.ignoring().antMatchers("/" + UrlConstant.DELETE_CONSUMER);
		// web.ignoring().antMatchers("/" + UrlConstant.DELETE_CONSUMER_ID);
		// web.ignoring().antMatchers("/" + UrlConstant.GET_CONSUMER_ID);
		// web.ignoring().antMatchers("/" + UrlConstant.CONSUMER);
		/**
		 * agent API
		 */

		/**
		 * Other services API
		 */

		web.ignoring().antMatchers("/" + UrlConstant.BLOCK_ACCOUNT_REQUEST_BY_USER);
		web.ignoring().antMatchers("/" + UrlConstant.RESET_PASS_AGAINST_FORGERY_LOGIN);

		/*
		 * BID API
		 * 
		 * /* Google Service Api
		 */

		web.ignoring().antMatchers("/confirm-account");
		web.ignoring().antMatchers("/" + UrlConstant.UPLOADIMAGE);
		web.ignoring().antMatchers("/" + UrlConstant.GETIMAGE);
		web.ignoring().antMatchers("/" + UrlConstant.AGENTREGISTER);
	}

}
